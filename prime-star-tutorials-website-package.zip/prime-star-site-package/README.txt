PRIME STAR TUTORIALS WEBSITE

The website entry file is index.html. It includes the Prime Star logo embedded in the file and links every Register button to the existing Tally form:
https://tally.so/r/4aQqaB

To publish with GitHub Pages:
1. Open the GitHub repository that will host the website.
2. Upload index.html to the repository's main/root folder.
3. If an index.html already exists, replace it only if you want this new design to become the live homepage. Keep a backup of the old file first.
4. Open repository Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch, select the main branch and /(root), then Save.
6. Wait for GitHub Pages to finish deployment and open the Pages URL shown in Settings > Pages.

The Tally form remains hosted separately. The website's Register links open the form directly; no second registration form is created.
